package com.memestream.notifications

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val zipInput = findViewById<EditText>(R.id.zipInput)
        val subscribeZipBtn = findViewById<Button>(R.id.subscribeZipBtn)
        val unsubscribeZipBtn = findViewById<Button>(R.id.unsubscribeZipBtn)
        val subscribeTrendingBtn = findViewById<Button>(R.id.subscribeTrendingBtn)

        subscribeZipBtn.setOnClickListener {
            val zip = zipInput.text.toString().trim()
            if (zip.isNotEmpty()) {
                FirebaseMessaging.getInstance().subscribeToTopic("zip_$zip")
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Subscribed to zip $zip", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Subscribe failed", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }

        unsubscribeZipBtn.setOnClickListener {
            val zip = zipInput.text.toString().trim()
            if (zip.isNotEmpty()) {
                FirebaseMessaging.getInstance().unsubscribeFromTopic("zip_$zip")
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Unsubscribed from zip $zip", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Unsubscribe failed", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }

        subscribeTrendingBtn.setOnClickListener {
            FirebaseMessaging.getInstance().subscribeToTopic("trending")
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Subscribed to trending", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Subscribe failed", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}

# MemeStream Notifications (Android)

This Android module demonstrates receiving FCM push notifications and subscribing to topics:
- Topic per ZIP code: `zip_<ZIPCODE>` (e.g., `zip_02101`)
- Global trending topic: `trending`

Setup steps:
1. Create Firebase project and add Android app.
2. Download `google-services.json` and place in `android-app/app/`.
3. Ensure Firebase Cloud Messaging is enabled (it's on by default).
4. Build and run the app. Use the backend below to send test notifications.

import express from 'express';
import admin from 'firebase-admin';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';

dotenv.config();
const app = express();
app.use(bodyParser.json());

// Initialize firebase-admin
if (!admin.apps.length) {
  const serviceAccountPath = process.env.SERVICE_ACCOUNT_PATH || './serviceAccountKey.json';
  try {
    const serviceAccount = require(serviceAccountPath);
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount)
    });
    console.log('firebase-admin initialized');
  } catch (err) {
    console.warn('Could not initialize firebase-admin. Add service account JSON and set SERVICE_ACCOUNT_PATH in .env');
  }
}

// Example endpoint to create a meme and send notifications
// Body should include: title, imageUrl, userId, zipCode (string), isTrending (boolean)
app.post('/memes', async (req, res) => {
  const { title, imageUrl, userId, zipCode, isTrending } = req.body;
  // TODO: save meme to DB (omitted here - integrate with your REST API)
  // Send notification to zip topic
  try {
    const messages = [];

    if (zipCode) {
      messages.push({
        topic: `zip_${zipCode}`,
        notification: {
          title: `New meme near ${zipCode}`,
          body: `${title} — posted by ${userId}`
        },
        data: {
          title,
          body: `New meme near ${zipCode}`,
          zipCode: zipCode
        }
      });
    }

    if (isTrending) {
      messages.push({
        topic: 'trending',
        notification: {
          title: 'Trending meme!',
          body: `${title} is trending now!`
        },
        data: {
          title,
          body: `${title} is trending!`
        }
      });
    }

    // Send all messages
    for (const msg of messages) {
      await admin.messaging().send(msg);
    }

    res.json({ success: true, sent: messages.length });
  } catch (err) {
    console.error('FCM send error:', err);
    res.status(500).json({ error: err.message });
  }
});

const port = process.env.PORT || 5001;
app.listen(port, () => console.log(`Notifications backend listening on ${port}`));

# MemeStream Notifications Backend (Node.js + firebase-admin)

This backend demonstrates sending Firebase Cloud Messaging (FCM) notifications when a new meme is posted.

## How it works
- POST /memes accepts a JSON body with fields: title, imageUrl, userId, zipCode (string), isTrending (boolean)
- It sends FCM messages to:
  - Topic `zip_<zipCode>` if zipCode is provided
  - Topic `trending` if isTrending is true

## Setup
1. Create a Firebase project and generate a service account JSON (Firebase Console -> Project settings -> Service accounts).
2. Place the service account JSON in this directory (or anywhere and set `SERVICE_ACCOUNT_PATH` in `.env`).
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start server:
   ```bash
   npm start
   ```
5. Use the Android app to subscribe to topics (zip_X or trending), then POST to `/memes` to trigger notifications.
